#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/12/31 10:22
# @Author  : AsiHacker
# @File    : demo.py
# @Software: PyCharm
# @notice  : True masters always have the heart of an apprentice.
import os
from pathlib import Path


# 3.创建包含子目录的目录
# print(os.makedirs('tmp_level0/tmp_level1'))
# 4.删除目录和文件
print(os.remove('tmp.txt'))