#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/12/31 10:57
# @Author  : AsiHacker
# @File    : 显示当前目录.py
# @Software: PyCharm
# @notice  : True masters always have the heart of an apprentice.
import os

print(os.getcwd())